#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "EMSRequestManager.h"
#import "EMSRequestModelBuilder.h"
#import "EMSRequestModel.h"
#import "EMSResponseModel.h"
#import "EMSCompositeRequestModel.h"
#import "EMSRequestModelRepositoryProtocol.h"
#import "EMSRequestModelRepository.h"
#import "EMSLogRepositoryProtocol.h"
#import "EMSLogHandlerProtocol.h"
#import "EMSRepositoryProtocol.h"
#import "EMSSQLSpecificationProtocol.h"
#import "EMSSQLiteHelper.h"
#import "EMSModelMapperProtocol.h"
#import "EMSRequestContract.h"
#import "EMSLogger.h"
#import "EMSLoggerSettings.h"
#import "NSError+EMSCore.h"
#import "NSDate+EMSCore.h"
#import "NSDictionary+EMSCore.h"
#import "EMSDictionaryValidator.h"
#import "EMSAuthentication.h"
#import "EMSDeviceInfo.h"
#import "EMSCoreCompletion.h"
#import "EMSRESTClient.h"
#import "EMSTimestampProvider.h"

FOUNDATION_EXPORT double CoreSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char CoreSDKVersionString[];

